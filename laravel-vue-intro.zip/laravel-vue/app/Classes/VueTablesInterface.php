<?php
namespace App\Classes;

Interface VueTablesInterface {
	public function get($table, Array $fields);
}
<?php

namespace CompropagoSdk\Factory\Models;

class FeeDetails
{
    public $amount;
    public $currency;
    public $type;
    public $description;
    public $application;
    public $tax_percent;
    public $amount_refunded;
    public $tax;
}
<?php

namespace CompropagoSdk\Factory\Models;


class Exchange
{
    public $rate;
    public $request;
    public $origin_amount;
    public $final_amount;
    public $origin_currency;
    public $final_currency;
    public $exchange_id;
}
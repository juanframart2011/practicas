<?php

namespace CompropagoSdk\Factory\Models;

class Webhook
{
    public $id;
    public $url;
    public $mode;
    public $status;
}
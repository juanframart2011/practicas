<?php

namespace CompropagoSdk\Factory\Models;

class Customer
{
    public $customer_name;
    public $customer_email;
    public $customer_phone;
}
<?php

namespace CompropagoSdk\Factory\Models;

class SmsObject
{
    public $id;
    public $object;
    public $short_id;
}
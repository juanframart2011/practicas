<?php

namespace CompropagoSdk\Factory\Models;

class EvalAuthInfo
{
    public $type;
    public $livemode;
    public $mode_key;
    public $message;
    public $code;

}